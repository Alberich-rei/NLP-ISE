DEEPSEEK_V3_API_KEY = "sk-uwrnrkhguelygkhglltbbdrmxuapcopybmufbtvnoptstjpg"
DEEPSEEK_V3_BASE_URL = "https://api.siliconflow.cn/v1"
DEEPSEEK_V3_MODEL = "deepseek-ai/DeepSeek-V3"

HKGAI_BASE_URL = "https://oneapi.hkgai.net/v1"
HKGAI_API_KEY = "sk-iqA1pjC48rpFXdkU7cCaE3BfBc9145B4BfCbEe0912126646"
HKGAI_MODEL = "HKGAI-V1"

SERP_API_KEY = "812943321eafd7ed60bf9c0bdea5422e91e3a5030f24d536620e56c0fd959e85"

ALPHA_VANTAGE_API_KEY = "PDBYANU8NGMST6SC"
